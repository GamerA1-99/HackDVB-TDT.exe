#ifndef PARSER_H
#define PARSER_H

extern void setup(int runde,char *sendbuffer);
extern void genframe(char *sendbuffer);

#endif // PARSER_H



